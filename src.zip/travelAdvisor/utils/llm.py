# utils/llm.py
from langchain_openai import ChatOpenAI

def get_llm(model_name: str):
    return ChatOpenAI(
        base_url="http://localhost:11434/v1",
        api_key="ollama",           # dummy value
        model=model_name,
        temperature=0.35,
        max_tokens=2000
    )