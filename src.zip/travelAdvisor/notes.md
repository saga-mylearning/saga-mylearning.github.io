travel-advisor/
├── app.py                      # ← Entry point: Streamlit UI + orchestrates everything
├── requirements.txt
├── .env                        # TAVILY_API_KEY=...
├── README.md
│
├── agents/                     # Individual agent definitions + prompts
│   ├── __init__.py
│   ├── researcher.py
│   ├── planner.py
│   ├── critic.py
│   └── supervisor.py
│
├── graph/                      # Graph construction, state, routing
│   ├── __init__.py
│   ├── state.py                # AgentState TypedDict
│   ├── nodes.py                # Agent nodes (wrappers)
│   ├── edges.py                # Routing / conditional edges
│   └── builder.py              # Main graph compilation
│
├── tools/                      # Custom / reusable tools
│   ├── __init__.py
│   └── tavily.py
│
├── utils/                      # Helpers (formatting, persistence, etc.)
│   ├── __init__.py
│   ├── llm.py                  # LLM factory (Ollama / other)
│   └── persistence.py          # Optional checkpoint saver
│
└── pages/                      # (optional) Streamlit multi-page if you want to grow
    └── debug_graph.py