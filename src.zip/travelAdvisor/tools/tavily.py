# tools/tavily.py
from langchain_community.tools.tavily_search import TavilySearchResults
from langchain_core.tools import tool


@tool
def tavily_search(query: str, max_results: int = 5) -> str:
    """
    Search the web using Tavily (real-time search engine optimized for LLMs).
    Returns a list of relevant web results with title, url, and content snippet.
    """
    tavily = TavilySearchResults(
        max_results=max_results,
        include_answer=False,
        include_raw_content=False,
        include_images=False,
    )
    try:
        results = tavily.invoke({"query": query})
        formatted = []
        for r in results:
            formatted.append(
                f"Title: {r['title']}\n"
                f"URL: {r['url']}\n"
                f"Content: {r['content'][:400]}{'...' if len(r['content']) > 400 else ''}\n"
            )
        return "\n---\n".join(formatted) or "No relevant results found."
    except Exception as e:
        return f"Search error: {str(e)}"


# Also expose the original tool if you want to use it directly in create_react_agent
tavily_tool = TavilySearchResults(max_results=4)