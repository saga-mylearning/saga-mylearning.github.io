
# app.py  (updated part — replace the "if st.button("✈️ Generate Trip Plan")" block)

if st.button("✈️ Generate Trip Plan", type="primary"):
    if not tavily_key.strip():
        st.error("Please provide a Tavily API key")
        st.stop()

    query = f"""..."""   # same as before

    llm = get_llm(model_name)
    checkpointer = get_checkpointer()   # persistent across reruns if you want
    graph = build_travel_graph(llm, checkpointer=checkpointer)

    thread_id = f"travel-{destination.replace(' ', '-')}-{int(datetime.now().timestamp())}"
    config = {"configurable": {"thread_id": thread_id}}

    inputs = {"messages": [HumanMessage(content=query)]}

    st.session_state.current_state = None
    st.session_state.final_itinerary = ""

    placeholder = st.empty()
    status = st.status("Planning your trip...", expanded=True)

    while True:
        with status:
            events = []
            for event in graph.stream(inputs, config, stream_mode="values"):
                events.append(event)
                if "messages" in event and event["messages"]:
                    last = event["messages"][-1]
                    role = last.additional_kwargs.get("agent", last.type)
                    content_preview = last.content[:180] + "..." if len(last.content) > 180 else last.content
                    st.write(f"**{role.upper()}**: {content_preview}")

            # Check if interrupted
            state = graph.get_state(config)
            if state.next:  # still nodes to run → not finished
                interrupted_before = state.next[0] if state.next else None

                st.session_state.current_state = state

                placeholder.markdown("### ⏸ Paused — Human Review Required")

                st.info(f"Paused { 'after research' if 'researcher' in state.metadata.get('interrupt_after', []) else 'before planning' }")

                last_message = state.values["messages"][-1].content if state.values["messages"] else ""

                st.markdown("**Latest output / context:**")
                st.markdown(last_message)

                col1, col2 = st.columns(2)
                with col1:
                    feedback = st.text_area("Your feedback / instructions / changes (optional)", height=120,
                                            placeholder="e.g. Add more food recommendations, focus on budget hotels, skip museums...")
                with col2:
                    decision = st.radio("Decision", ["Continue", "Edit & Continue", "Restart from beginning"])

                if st.button("Resume Execution"):
                    if decision == "Restart from beginning":
                        graph.update_state(config, {"messages": [HumanMessage(content=query)]}, as_node="supervisor")
                    elif feedback.strip():
                        # Inject human feedback as new message
                        graph.update_state(
                            config,
                            {"messages": [HumanMessage(content=f"Human feedback: {feedback}")]},
                            as_node=state.next[0] if state.next else None
                        )
                    else:
                        # Just continue
                        graph.update_state(config, None)

                    st.rerun()  # loop again

                    # If no more interrupts and reached END
                    if not state.next:
                        final_msg = state.values["messages"][-1].content
                        st.session_state.final_itinerary = final_msg
                        status.update(label="Trip plan complete!", state="complete")
                        st.success("Itinerary ready!")
                        st.markdown("### Final Itinerary")
                        st.markdown(final_msg)
                        break

            else:
                # No more interrupts, graph finished
                final_msg = state.values["messages"][-1].content
                st.session_state.final_itinerary = final_msg
                status.update(label="Trip plan complete!", state="complete")
                st.success("Itinerary ready!")
                st.markdown("### Final Itinerary")
                st.markdown(final_msg)
                break