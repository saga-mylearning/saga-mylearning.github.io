def route_after_supervisor(state) -> Literal["researcher", "planner", "critic", "FINISH"]:
    last_message = state["messages"][-1]
    content = last_message.content.lower().strip()

    for member in ["researcher", "planner", "critic", "finish"]:
        if member in content:
            if member == "finish":
                return "FINISH"
            return member

    # fallback
    return "researcher"