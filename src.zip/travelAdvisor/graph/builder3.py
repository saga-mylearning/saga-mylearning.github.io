# graph/builder.py (partial)

from agents.supervisor import create_supervisor
from graph.edges import route_after_supervisor

def build_travel_graph(llm):
    supervisor_chain = create_supervisor(llm)
    # ... other chains ...

    workflow = StateGraph(state_schema=AgentState)

    workflow.add_node("supervisor", supervisor_node(supervisor_chain))
    # ... other nodes ...

    workflow.add_conditional_edges(
        source="supervisor",
        path=route_after_supervisor,
        path_map={
            "researcher": "researcher",
            "planner":    "planner",
            "critic":     "critic",
            "FINISH":     END
        }
    )

    workflow.add_edge(START, "supervisor")

    return workflow.compile()