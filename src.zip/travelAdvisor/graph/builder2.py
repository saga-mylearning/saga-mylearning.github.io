# (snippet from builder.py)

from graph.edges import route_after_supervisor
from agents.researcher import create_researcher
# ... other imports

def build_travel_graph(llm):
    researcher_chain = create_researcher(llm)
    # ... create planner_chain, critic_chain, supervisor_chain ...

    workflow = StateGraph(state_schema=AgentState)

    workflow.add_node("researcher", lambda state: researcher_chain.invoke(state))
    # ... add other nodes ...

    workflow.add_conditional_edges(
        "supervisor",
        route_after_supervisor,
        {
            "researcher": "researcher",
            "planner": "planner",
            "critic": "critic",
            "FINISH": END,
        }
    )
    # ...