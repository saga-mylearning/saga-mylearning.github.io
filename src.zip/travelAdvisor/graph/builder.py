# graph/builder.py   (updated)
from langgraph.graph import StateGraph, START, END
# ... other imports ...

from utils.persistence import get_checkpointer

def build_travel_graph(llm, checkpointer=None):
    # ... create researcher_chain, planner_chain, critic_chain, supervisor_chain ...

    workflow = StateGraph(state_schema=AgentState)

    workflow.add_node("researcher", researcher_node(researcher_chain))
    workflow.add_node("planner",    planner_node(planner_chain))
    workflow.add_node("critic",     critic_node(critic_chain))
    workflow.add_node("supervisor", supervisor_node(supervisor_chain))

    # Edges from workers → supervisor
    for member in ["researcher", "planner", "critic"]:
        workflow.add_edge(member, "supervisor")

    # Supervisor decides next
    workflow.add_conditional_edges(
        "supervisor",
        route_after_supervisor,
        {
            "researcher": "researcher",
            "planner":    "planner",
            "critic":     "critic",
            "FINISH":     END
        }
    )

    workflow.add_edge(START, "supervisor")

    # ─── Human-in-the-loop INTERRUPTS ───────────────────────────────
    # Pause after research → human can review facts / add instructions
    # Pause before planning → human gives final approval / correction
    return workflow.compile(
        checkpointer=checkpointer or get_checkpointer(),
        interrupt_after=["researcher"],       # review research output
        interrupt_before=["planner"]          # approve / tweak before full plan
    )