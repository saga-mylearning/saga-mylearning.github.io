# graph/builder.py
from langgraph.graph import StateGraph, START, END
from agents.researcher import create_researcher
from agents.planner import create_planner
from agents.critic import create_critic
from agents.supervisor import create_supervisor
from graph.state import AgentState
from graph.nodes import researcher_node, planner_node, critic_node, supervisor_node
from graph.edges import route_after_supervisor

def build_travel_graph(llm):
    # Create individual agents
    researcher = create_researcher(llm)
    planner    = create_planner(llm)
    critic     = create_critic(llm)
    supervisor = create_supervisor(llm)

    # Build graph
    workflow = StateGraph(state_schema=AgentState)

    workflow.add_node("researcher", researcher_node(researcher))
    workflow.add_node("planner",    planner_node(planner))
    workflow.add_node("critic",     critic_node(critic))
    workflow.add_node("supervisor", supervisor_node(supervisor))

    # Edges: everyone → supervisor
    for member in ["researcher", "planner", "critic"]:
        workflow.add_edge(member, "supervisor")

    # Conditional routing from supervisor
    workflow.add_conditional_edges(
        "supervisor",
        route_after_supervisor,
        {
            "researcher": "researcher",
            "planner":    "planner",
            "critic":     "critic",
            "FINISH":     END
        }
    )

    workflow.add_edge(START, "supervisor")

    return workflow.compile()