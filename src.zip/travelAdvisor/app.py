# app.py
import streamlit as st
from dotenv import load_dotenv
from travelAdvisor.graph.builderX import build_travel_graph
from utils.llm import get_llm
from utils.persistence import get_checkpointer  # optional

load_dotenv()

st.set_page_config(page_title="Travel Advisor AI", page_icon="✈️", layout="wide")

st.title("🌍 Multi-Agent Travel Advisor")
st.caption("Supervisor + Researcher + Planner + Critic • LangGraph + Ollama")

# Sidebar controls
with st.sidebar:
    st.header("Settings")
    model_name = st.selectbox(
        "Ollama Model",
        ["llama3.1:8b", "qwen2.5:14b", "gemma2:27b", "phi-4:14b"],
        index=0
    )
    tavily_key = st.text_input("Tavily API Key", type="password")
    if tavily_key:
        import os
        os.environ["TAVILY_API_KEY"] = tavily_key

# Main content
destination = st.text_input("Destination", "Tokyo, Japan")
travel_dates = st.text_input("Dates", "2026-07-10 to 2026-07-20")
budget_usd = st.number_input("Budget (USD)", 500, 15000, 3500)
travelers = st.number_input("Number of people", 1, 10, 2)
interests = st.multiselect(
    "Interests",
    ["Culture", "Food", "Nature", "Shopping", "History", "Adventure", "Relaxation"],
    default=["Culture", "Food"]
)

if st.button("✈️ Generate Trip Plan", type="primary"):
    if not tavily_key.strip():
        st.error("Please provide a Tavily API key")
        st.stop()

    query = f"""
Plan a complete trip to {destination} from {travel_dates}.
Budget: ${budget_usd} total for {travelers} people.
Priorities: {', '.join(interests) or 'general sightseeing'}.
Include flights (if needed), accommodation, daily itinerary, estimated costs.
    """.strip()

    with st.spinner("Agents are collaborating..."):
        llm = get_llm(model_name)
        graph = build_travel_graph(llm)

        config = {"configurable": {"thread_id": "travel-1"}}  # can be dynamic

        inputs = {"messages": [{"role": "user", "content": query}]}

        result_container = st.container()

        final_output = ""
        for event in graph.stream(inputs, config, stream_mode="values"):
            if "messages" in event and event["messages"]:
                last_msg = event["messages"][-1]
                if isinstance(last_msg.content, str) and last_msg.content.strip():
                    with result_container:
                        role = last_msg.additional_kwargs.get("agent", "Unknown")
                        st.markdown(f"**{role}** → {last_msg.content[:400]}{'...' if len(last_msg.content)>400 else ''}")
                    if "final" in last_msg.content.lower() or len(event["messages"]) > 12:
                        final_output = last_msg.content
                        break

        if final_output:
            st.success("Trip plan ready!")
            st.markdown("### Final Itinerary")
            st.markdown(final_output)

        else:
            st.warning("No final output captured – check agent logic")
