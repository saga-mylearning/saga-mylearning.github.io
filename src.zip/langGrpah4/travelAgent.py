# app.py - Multi-Agent Travel Advisor with LangGraph + Streamlit
# Educational version inspired by freeCodeCamp LangGraph Course

import streamlit as st
from typing import TypedDict, Annotated, List
from langgraph.graph import StateGraph, START, END
from langgraph.prebuilt import create_react_agent
from langchain_openai import ChatOpenAI
from langchain_community.tools.tavily_search import TavilySearchResults
from langchain_core.messages import HumanMessage
import json

st.set_page_config(page_title="🌍 Travel Advisor AI", page_icon="✈️", layout="wide")

# ================== STYLING ==================
st.markdown("""
<style>
    .stApp { background: #0a0a0f; color: #e8e8f0; }
    .agent-step { background: #1a1a26; padding: 12px; border-radius: 8px; margin: 8px 0; border-left: 4px solid #7c6af5; }
</style>
""", unsafe_allow_html=True)

# ================== SESSION STATE ==================
if "trip_data" not in st.session_state:
    st.session_state.trip_data = {}
if "messages" not in st.session_state:
    st.session_state.messages = []
if "graph_result" not in st.session_state:
    st.session_state.graph_result = None

# ================== OLLAMA + TAVILY SETUP ==================
@st.cache_resource
def get_llm(model: str):
    return ChatOpenAI(
        base_url="http://localhost:11434/v1",
        model=model,
        api_key="ollama",
        temperature=0.3
    )

@st.cache_resource
def get_tavily_tool():
    return TavilySearchResults(max_results=4)

# ================== LANGGRAPH - MULTI-AGENT SUPERVISOR ==================
class AgentState(TypedDict):
    messages: Annotated[list, "add_messages"]
    next: str

def create_travel_graph(llm):
    tavily_tool = get_tavily_tool()

    # Worker Agents
    researcher = create_react_agent(
        llm, 
        [tavily_tool], 
        name="Researcher",
        prompt="You are a world-class travel researcher. Use tools to find real flights, hotels, weather, attractions."
    )

    planner = create_react_agent(
        llm, 
        [], 
        name="Planner",
        prompt="You are an expert itinerary planner. Create detailed day-by-day plans based on research."
    )

    critic = create_react_agent(
        llm, 
        [], 
        name="Critic",
        prompt="You are a strict travel critic. Check budget, realism, safety, and suggest improvements."
    )

    # Supervisor
    members = ["Researcher", "Planner", "Critic"]
    supervisor_prompt = (
        f"You are the Travel Supervisor. Your job is to coordinate the team: {members}.\n"
        "Decide who should act next or respond with FINISH when the itinerary is complete and polished.\n"
        "Only return the exact name of the next agent or 'FINISH'."
    )

    supervisor = create_react_agent(llm, [], name="Supervisor", prompt=supervisor_prompt)

    # Build Graph
    graph = StateGraph(AgentState)

    graph.add_node("Researcher", researcher)
    graph.add_node("Planner", planner)
    graph.add_node("Critic", critic)
    graph.add_node("Supervisor", supervisor)

    # Routing logic
    def route_supervisor(state):
        last_message = state["messages"][-1].content.strip()
        if "FINISH" in last_message.upper():
            return END
        for member in members:
            if member in last_message:
                return member
        return "Researcher"  # default

    for member in members:
        graph.add_edge(member, "Supervisor")

    graph.add_conditional_edges("Supervisor", route_supervisor)

    graph.add_edge(START, "Supervisor")

    return graph.compile()

# ================== STREAMLIT UI ==================
st.title("🌍 Multi-Agent Travel Advisor")
st.caption("LangGraph Supervisor • Researcher • Planner • Critic • Powered by Ollama")

# Sidebar
with st.sidebar:
    st.header("Trip Details")
    destination = st.text_input("Destination", placeholder="Bali, Indonesia")
    dates = st.text_input("Travel Dates", placeholder="2026-06-15 to 2026-06-25")
    budget = st.number_input("Budget (USD)", min_value=500, value=2500)
    travelers = st.number_input("Number of Travelers", min_value=1, value=2)
    interests = st.multiselect("Interests", 
                               ["Beach", "Adventure", "Culture", "Food", "Luxury", "Budget", "Hiking", "History"])

    model = st.selectbox("Ollama Model", 
                         ["llama3.1:8b", "qwen2.5:14b", "gemma2:27b", "phi-4:14b"], index=0)

    tavily_key = st.text_input("Tavily API Key", type="password", 
                               help="Free at https://app.tavily.com (1000 searches/month)")

    if st.button("✈️ Generate Itinerary", type="primary", use_container_width=True):
        if not tavily_key:
            st.error("Please enter your Tavily API key")
        else:
            st.session_state.trip_data = {
                "destination": destination,
                "dates": dates,
                "budget": budget,
                "travelers": travelers,
                "interests": interests
            }
            st.session_state.messages = []

# Main Area
col1, col2 = st.columns([3, 1])

with col1:
    if st.session_state.trip_data:
        trip = st.session_state.trip_data
        st.info(f"**Planning trip to {trip['destination']}** • {trip['dates']} • ${trip['budget']} budget")

        if st.button("🚀 Run Multi-Agent Planning"):
            with st.spinner("Agents are working..."):
                llm = get_llm(model)
                graph = create_travel_graph(llm)

                query = f"""Plan a complete trip to {trip['destination']} from {trip['dates']}.
Budget: ${trip['budget']} for {trip['travelers']} people.
Interests: {', '.join(trip['interests']) if trip['interests'] else 'general sightseeing'}."""

                inputs = {"messages": [HumanMessage(content=query)]}

                result = ""
                steps_container = st.container()

                for event in graph.stream(inputs, stream_mode="values"):
                    if "messages" in event:
                        msg = event["messages"][-1]
                        if hasattr(msg, "content"):
                            result = msg.content
                            with steps_container:
                                st.markdown(f"<div class='agent-step'><strong>Agent Output:</strong><br>{msg.content[:300]}...</div>", unsafe_allow_html=True)

                st.session_state.graph_result = result
                st.success("Itinerary Ready!")

    if st.session_state.graph_result:
        st.subheader("📋 Final Itinerary")
        st.markdown(st.session_state.graph_result)

with col2:
    st.subheader("Graph Visualization")
    st.markdown("""
```mermaid
graph TD
    A[Supervisor] --> B[Researcher]
    A --> C[Planner]
    A --> D[Critic]
    B --> A
    C --> A
    D --> A
    A --> E[FINISH]