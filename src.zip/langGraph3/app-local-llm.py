# app.py - Local FAQ RAG Chat with Ollama + sentence-transformers
# March 2026 version – fully offline after model download

import streamlit as st
import json
import os
import numpy as np
from sentence_transformers import SentenceTransformer
import requests
from datetime import datetime

st.set_page_config(
    page_title="Local FAQ RAG • Ollama",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ─── Styling ────────────────────────────────────────────────────────────────
st.markdown("""
    <style>
    :root { --bg: #0a0a0f; --surface: #12121a; --surface2: #1a1a26; --border: #2a2a3d;
            --accent: #7c6af5; --accent2: #c084fc; --text: #e8e8f0; --muted: #7070a0; }
    .stApp { background: var(--bg); color: var(--text); }
    section[data-testid="stSidebar"] { background: var(--surface) !important; border-right: 1px solid var(--border); }
    .stTextInput input, .stTextArea textarea {
        background: var(--surface2); border: 1px solid var(--border); color: var(--text);
        font-family: 'DM Mono', monospace;
    }
    .stButton > button { background: linear-gradient(135deg, var(--accent), var(--accent2)); color: white; border: none; }
    .chat-user { background: #1e1b4b; border: 1px solid var(--accent); border-radius: 12px; border-bottom-right-radius: 2px;
                 padding: 12px 16px; margin: 8px 0; max-width: 80%; align-self: flex-end; color: #c4b5fd; }
    .chat-bot { background: #131320; border: 1px solid var(--border); border-radius: 12px; border-bottom-left-radius: 2px;
                padding: 12px 16px; margin: 8px 0; max-width: 80%; align-self: flex-start; color: var(--text); }
    .sources { font-size: 0.75rem; color: var(--muted); margin-top: 6px; }
    .sources span { background: rgba(124,106,245,0.15); border: 1px solid rgba(124,106,245,0.3);
                    color: var(--accent2); padding: 2px 8px; border-radius: 4px; margin-right: 4px; }
    .empty-hint { text-align: center; color: var(--muted); padding: 80px 20px; opacity: 0.6; }
    </style>
""", unsafe_allow_html=True)

# ─── Session & Persistence ──────────────────────────────────────────────────
FAQ_FILE = "faqs_local.json"

def load_faqs():
    if os.path.exists(FAQ_FILE):
        try:
            with open(FAQ_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except:
            pass
    return [
        {"q": "What is your return policy?", "a": "We offer a 30-day hassle-free return policy..."},
        {"q": "How long does shipping take?", "a": "Standard shipping takes 5–7 business days..."},
        # ... (keep your original seed data)
    ]

if "faqs" not in st.session_state:
    st.session_state.faqs = load_faqs()

if "messages" not in st.session_state:
    st.session_state.messages = []

# ─── Local Embedder (sentence-transformers) ─────────────────────────────────
@st.cache_resource
def load_embedder():
    return SentenceTransformer('all-MiniLM-L6-v2')

embedder = load_embedder()

def compute_faq_embeddings():
    if not st.session_state.faqs:
        st.session_state.faq_embeddings = None
        return
    texts = [f"{f['q']} {f['a']}" for f in st.session_state.faqs]
    st.session_state.faq_embeddings = embedder.encode(texts, normalize_embeddings=True)

if "faq_embeddings" not in st.session_state:
    compute_faq_embeddings()

# ─── Retrieval ──────────────────────────────────────────────────────────────
def retrieve_relevant(query: str, top_k: int = 4, min_score: float = 0.32):
    if "faq_embeddings" not in st.session_state or st.session_state.faq_embeddings is None:
        return []
    q_emb = embedder.encode([query], normalize_embeddings=True)[0]
    sims = np.dot(st.session_state.faq_embeddings, q_emb)
    idx = np.argsort(sims)[::-1][:top_k]
    return [
        {"faq": st.session_state.faqs[i], "score": float(sims[i])}
        for i in idx if sims[i] >= min_score
    ]

# ─── Ollama Chat (streaming) ────────────────────────────────────────────────
def call_ollama(messages, model="llama3.2:3b", temperature=0.3):
    payload = {
        "model": model,
        "messages": messages,
        "stream": True,
        "options": {"temperature": temperature}
    }
    try:
        with requests.post("http://localhost:11434/", json=payload, stream=True) as r:
            r.raise_for_status()
            for line in r.iter_lines():
                if line:
                    data = json.loads(line)
                    if "message" in data and "content" in data["message"]:
                        yield data["message"]["content"]
                    if data.get("done", False):
                        break
    except Exception as e:
        yield f"**Error communicating with Ollama:** {str(e)}"

# ─── Sidebar ────────────────────────────────────────────────────────────────
with st.sidebar:
    st.title("Local FAQ RAG")
    st.caption("100% offline – Ollama + sentence-transformers")

    ollama_model = st.selectbox(
        "Ollama Model",
        ["llama3.1:8b", "qwen2.5:14b", "gemma3:12b", "phi-4:14b", "mistral-nemo:12b"],
        index=0
    )

    st.divider()
    st.subheader("Knowledge Base")
    st.caption(f"{len(st.session_state.faqs)} entries")

    new_q = st.text_input("New Question")
    new_a = st.text_area("Answer", height=100)

    if st.button("➕ Add"):
        q, a = new_q.strip(), new_a.strip()
        if q and a:
            st.session_state.faqs.append({"q": q, "a": a})
            with open(FAQ_FILE, "w", encoding="utf-8") as f:
                json.dump(st.session_state.faqs, f, ensure_ascii=False, indent=2)
            compute_faq_embeddings()
            st.success("Added")
            st.rerun()

    st.divider()
    for i, faq in enumerate(st.session_state.faqs):
        with st.expander(f"{faq['q'][:50]}{'…' if len(faq['q'])>50 else ''}"):
            st.write(f"**Q** {faq['q']}")
            st.write(f"**A** {faq['a']}")
            if st.button("🗑", key=f"del_{i}"):
                st.session_state.faqs.pop(i)
                with open(FAQ_FILE, "w", encoding="utf-8") as f:
                    json.dump(st.session_state.faqs, f, ensure_ascii=False, indent=2)
                compute_faq_embeddings()
                st.rerun()

# ─── Main Chat ──────────────────────────────────────────────────────────────
st.header("Local RAG Chat with Ollama")

chat_container = st.container()
with chat_container:
    if not st.session_state.messages:
        st.markdown('<div class="empty-hint">Add FAQs • Ask anything below</div>', unsafe_allow_html=True)

    for msg in st.session_state.messages:
        cls = "chat-user" if msg["role"] == "user" else "chat-bot"
        sources_html = ""
        if "sources" in msg and msg["sources"]:
            sources_html = '<div class="sources">📎 ' + " ".join(f'<span>{s}</span>' for s in msg["sources"]) + '</div>'
        st.markdown(f'<div class="{cls}">{msg["content"]}{sources_html}</div>', unsafe_allow_html=True)

user_input = st.chat_input("Ask about products, orders, returns...")

if user_input:
    st.session_state.messages.append({"role": "user", "content": user_input})

    relevant = retrieve_relevant(user_input)

    sources_list = []
    context = ""
    if relevant:
        context = "### Relevant FAQ entries (use ONLY these):\n\n"
        for i, item in enumerate(relevant, 1):
            f = item["faq"]
            context += f"FAQ {i} (score {item['score']:.2f}):\nQ: {f['q']}\nA: {f['a']}\n\n"
            short = f['q'][:35] + "…" if len(f['q']) > 35 else f['q']
            sources_list.append(f"{short} ({item['score']:.2f})")
    else:
        context = "### No relevant FAQ entries found.\n"

    system_msg = f"""You are a concise, friendly customer support agent.
Answer using ONLY the provided FAQ entries.
If nothing matches, say: "I don't have specific information on that in our FAQ base."

{context}"""

    # Build full messages list with system prompt
    full_messages = [{"role": "system", "content": system_msg}] + st.session_state.messages

    # Display assistant placeholder
    with st.chat_message("assistant"):
        message_placeholder = st.empty()
        full_response = ""

        for chunk in call_ollama(full_messages, model=ollama_model):
            full_response += chunk
            message_placeholder.markdown(full_response + "▌")

        message_placeholder.markdown(full_response)

        st.session_state.messages.append({
            "role": "assistant",
            "content": full_response,
            "sources": sources_list if sources_list else None
        })