# Add to requirements
# pip install sentence-transformers
#VoyagerAPI: pa-hGU6UCbhEfsM0xE5CINc40_T1X5UUdqHkAa8Wj932SX
# app.py - FAQ RAG Chat with Voyage Embeddings, Multi-turn, Persistence & Evaluation
# Date: March 2026 version

import streamlit as st
import requests
import json
import os
import numpy as np
import voyageai
from datetime import datetime

st.set_page_config(
    page_title="FAQ RAG Chat • Voyage + Claude",
    page_icon="🔮",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ─── Styling (dark cyber theme) ─────────────────────────────────────────────
st.markdown("""
    <style>
    :root {
        --bg: #0a0a0f;
        --surface: #12121a;
        --surface2: #1a1a26;
        --border: #2a2a3d;
        --accent: #7c6af5;
        --accent2: #c084fc;
        --text: #e8e8f0;
        --muted: #7070a0;
    }
    .stApp { background: var(--bg); color: var(--text); }
    section[data-testid="stSidebar"] {
        background: var(--surface) !important;
        border-right: 1px solid var(--border);
    }
    .stTextInput > div > div > input,
    .stTextArea > div > div > textarea {
        background: var(--surface2);
        border: 1px solid var(--border);
        color: var(--text);
        font-family: 'DM Mono', monospace;
    }
    .stButton > button {
        background: linear-gradient(135deg, var(--accent), var(--accent2));
        color: white; border: none; font-weight: bold;
    }
    .stButton > button:hover { opacity: 0.92; transform: translateY(-1px); }
    .chat-user {
        background: #1e1b4b; border: 1px solid var(--accent);
        border-radius: 12px; border-bottom-right-radius: 2px;
        padding: 12px 16px; margin: 8px 0; max-width: 80%;
        align-self: flex-end; color: #c4b5fd; font-size: 0.95rem;
    }
    .chat-bot {
        background: #131320; border: 1px solid var(--border);
        border-radius: 12px; border-bottom-left-radius: 2px;
        padding: 12px 16px; margin: 8px 0; max-width: 80%;
        align-self: flex-start; color: var(--text); font-size: 0.95rem;
    }
    .sources { font-size: 0.75rem; color: var(--muted); margin-top: 6px; }
    .sources span {
        background: rgba(124,106,245,0.15); border: 1px solid rgba(124,106,245,0.3);
        color: var(--accent2); padding: 2px 8px; border-radius: 4px; margin-right: 4px;
    }
    .empty-hint { text-align: center; color: var(--muted); padding: 80px 20px; opacity: 0.6; }
    hr { border-color: var(--border) !important; }
    </style>
""", unsafe_allow_html=True)

# ─── Session State & Persistence ────────────────────────────────────────────
FAQ_FILE = "faqs.json"

def load_faqs():
    if os.path.exists(FAQ_FILE):
        try:
            with open(FAQ_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, list) and all("q" in item and "a" in item for item in data):
                    return data
        except:
            pass
    # Default seed data
    return [
        {"q": "What is your return policy?", "a": "We offer a 30-day hassle-free return policy. Items must be unused and in original packaging. Contact support@example.com to initiate a return."},
        {"q": "How long does shipping take?", "a": "Standard shipping takes 5–7 business days. Express shipping (2–3 days) is available at checkout. International orders may take 10–14 days."},
        {"q": "Do you offer customer support?", "a": "Yes! Our support team is available 24/7 via live chat, email at support@example.com, and phone at 1-800-555-0100."},
        {"q": "How do I reset my password?", "a": "Go to the login page and click 'Forgot Password'. Enter your email and we'll send a reset link within 2 minutes. Check your spam folder if you don't see it."},
        {"q": "Can I change or cancel my order?", "a": "Orders can be modified or cancelled within 1 hour of placement. After that, the order enters processing and changes may not be possible."},
    ]

if "faqs" not in st.session_state:
    st.session_state.faqs = load_faqs()

if "messages" not in st.session_state:
    st.session_state.messages = []

if "api_key_anthropic" not in st.session_state:
    st.session_state.api_key_anthropic = ""
if "api_key_voyage" not in st.session_state:
    st.session_state.api_key_voyage = ""

# ─── Voyage Client & Embeddings ─────────────────────────────────────────────
@st.cache_resource
def get_voyage_client():
    if not st.session_state.api_key_voyage:
        raise ValueError("Voyage API key not set")
    return voyageai.Client(api_key=st.session_state.api_key_voyage)

VOYAGE_EMBED_MODEL = "voyage-4-large"      # March 2026 flagship
VOYAGE_RERANK_MODEL = "rerank-2.5"         # latest high-quality reranker

def compute_faq_embeddings():
    if not st.session_state.faqs:
        st.session_state.faq_embeddings = None
        st.session_state.faq_texts = None
        return

    texts = [f"{f['q']} • {f['a']}" for f in st.session_state.faqs]  # • helps separation
    try:
        vo = get_voyage_client()
        result = vo.embed(
            texts=texts,
            model=VOYAGE_EMBED_MODEL,
            input_type="document"
        )
        st.session_state.faq_embeddings = np.array(result.embeddings)
        st.session_state.faq_texts = texts
    except Exception as e:
        st.error(f"Embedding failed: {e}")
        st.session_state.faq_embeddings = None

# Load / recompute embeddings on start or after FAQ change
if "faq_embeddings" not in st.session_state:
    compute_faq_embeddings()

# ─── Retrieval with Voyage + Rerank ─────────────────────────────────────────
def retrieve_relevant(query: str, top_k: int = 4, min_score: float = 0.25):
    if st.session_state.faq_embeddings is None:
        return []

    try:
        vo = get_voyage_client()

        # Query embedding (asymmetric)
        q_res = vo.embed([query], model=VOYAGE_EMBED_MODEL, input_type="query")
        q_emb = np.array(q_res.embeddings[0])

        # Fast approximate top-k
        sims = np.dot(st.session_state.faq_embeddings, q_emb)
        top_idx = np.argsort(sims)[::-1][:12]  # over-retrieve

        candidates = [st.session_state.faqs[i] for i in top_idx]
        cand_texts = [st.session_state.faq_texts[i] for i in top_idx]

        if len(candidates) <= 1:
            final_faqs = candidates[:top_k]
            final_scores = sims[top_idx[:top_k]].tolist()
        else:
            # Rerank
            rr = vo.rerank(
                query=query,
                documents=cand_texts,
                model=VOYAGE_RERANK_MODEL,
                top_k=top_k
            )
            final_faqs = []
            final_scores = []
            for r in rr.results:
                orig_idx = top_idx[r.index]
                final_faqs.append(st.session_state.faqs[orig_idx])
                final_scores.append(r.relevance_score)

        return [
            {"faq": f, "score": s}
            for f, s in zip(final_faqs, final_scores)
            if s >= min_score
        ]
    except Exception as e:
        st.error(f"Retrieval failed: {str(e)}")
        return []

# ─── History Trimming (multi-turn context control) ──────────────────────────
def trim_history(max_messages: int = 14):
    if len(st.session_state.messages) > max_messages:
        # Keep very first user message + last N-1
        first = next((m for m in st.session_state.messages if m["role"] == "user"), None)
        last_part = st.session_state.messages[-(max_messages-1):]
        trimmed = []
        if first:
            trimmed.append(first)
        trimmed.extend([m for m in last_part if m not in trimmed])
        st.session_state.messages = trimmed

# ─── System Prompt Builder (multi-turn aware) ───────────────────────────────
def build_system_prompt(relevant, history):
    recent = history[-8:]  # last 4 turns approx
    conv_summary = "\n".join(
        f"{'User' if m['role']=='user' else 'Assistant'}: {m['content'][:180]}{'...' if len(m['content'])>180 else ''}"
        for m in recent
    )

    context = "### Retrieved FAQ Entries (highest relevance first) ─ use ONLY these:\n\n"
    sources = []
    for i, item in enumerate(relevant, 1):
        f = item["faq"]
        score_str = f"{item['score']:.3f}"
        context += f"FAQ {i} (rel {score_str}):\nQ: {f['q']}\nA: {f['a']}\n\n"
        short = f['q'][:38] + "…" if len(f['q']) > 38 else f['q']
        sources.append(f"FAQ: {short} ({score_str})")

    if not relevant:
        context += "### No relevant FAQ entries found.\n"

    return f"""You are a concise, friendly customer support agent powered by a FAQ knowledge base and Claude.

<conversation>
{conv_summary if conv_summary else "(new conversation)"}
</conversation>

{context}

Rules:
• Answer using ONLY the provided FAQ entries
• Respect previous turns — maintain context and consistency
• If question refers to prior messages, connect logically
• If no FAQ covers it → "I don't have specific information on that in our FAQ base. Is there anything else I can help with?"
• Keep replies clear, professional, under 220 words
"""

# ─── Sidebar ────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("### 🔮 FAQ·RAG Chat")
    st.caption("Voyage-4-large + Claude • March 2026")

    st.divider()

    st.subheader("API Keys")
    # st.session_state.api_key_anthropic = st.text_input(
    #     "Anthropic API Key", value=st.session_state.api_key_anthropic, type="password",
    #     placeholder="sk-ant-..."
    # )
    st.session_state.api_key_voyage = st.text_input(
        "Voyage API Key", value=st.session_state.api_key_voyage, type="password",
        placeholder="voyage-..."
    )

    st.divider()

    st.subheader("Knowledge Base")
    st.caption(f"{len(st.session_state.faqs)} entries")

    new_q = st.text_input("New Question", placeholder="e.g. What is your warranty?")
    new_a = st.text_area("Answer", height=100, placeholder="Detailed answer here...")

    if st.button("➕ Add FAQ", use_container_width=True):
        q, a = new_q.strip(), new_a.strip()
        if q and a:
            st.session_state.faqs.append({"q": q, "a": a})
            with open(FAQ_FILE, "w", encoding="utf-8") as f:
                json.dump(st.session_state.faqs, f, ensure_ascii=False, indent=2)
            compute_faq_embeddings()
            st.success("Added & saved", icon="✅")
            st.rerun()
        else:
            st.warning("Both fields required")

    st.divider()

    for i, faq in enumerate(st.session_state.faqs):
        with st.expander(f"{faq['q'][:55]}{'…' if len(faq['q'])>55 else ''}"):
            st.markdown(f"**Q** {faq['q']}")
            st.markdown(f"**A** {faq['a']}")
            if st.button("🗑 Delete", key=f"del_{i}"):
                st.session_state.faqs.pop(i)
                with open(FAQ_FILE, "w", encoding="utf-8") as f:
                    json.dump(st.session_state.faqs, f, ensure_ascii=False, indent=2)
                compute_faq_embeddings()
                st.rerun()

# ─── Main Tabs ──────────────────────────────────────────────────────────────
tab_chat, tab_eval = st.tabs(["💬 Chat", "📊 Evaluation"])

with tab_chat:
    st.markdown("<h2 style='background: linear-gradient(90deg, #7c6af5, #c084fc); -webkit-background-clip:text; -webkit-text-fill-color:transparent;'>FAQ RAG Chat</h2>", unsafe_allow_html=True)

    # Chat messages
    chat_container = st.container()
    with chat_container:
        if not st.session_state.messages:
            st.markdown('<div class="empty-hint">Add FAQs in sidebar • Ask anything below ✨</div>', unsafe_allow_html=True)

        for msg in st.session_state.messages:
            if msg["role"] == "user":
                st.markdown(f'<div class="chat-user">{msg["content"]}</div>', unsafe_allow_html=True)
            else:
                sources_html = ""
                if "sources" in msg and msg["sources"]:
                    sources_html = '<div class="sources">📎 ' + " ".join(f'<span>{s}</span>' for s in msg["sources"]) + '</div>'
                st.markdown(
                    f'<div class="chat-bot">{msg["content"]}{sources_html}</div>',
                    unsafe_allow_html=True
                )

    # Input
    user_input = st.chat_input("Ask a question about our products / orders ...")

    if user_input:
        # if not st.session_state.api_key_anthropic.strip():
        #     st.error("Please provide Anthropic API key", icon="🔑")
        if not st.session_state.api_key_voyage.strip():
            st.error("Please provide Voyage API key", icon="🔑")
        else:
            st.session_state.messages.append({"role": "user", "content": user_input})

            relevant = retrieve_relevant(user_input)

            sources_list = []
            if relevant:
                sources_list = [f"FAQ: {r['faq']['q'][:35]}… ({r['score']:.3f})" for r in relevant]

            system = build_system_prompt(relevant, st.session_state.messages)

            trim_history()

            with st.chat_message("assistant"):
                with st.spinner("Retrieving & thinking..."):
                    try:
                        resp = requests.post(
                            "https://api.anthropic.com/v1/messages",
                            headers={
                                "x-api-key": st.session_state.api_key_anthropic,
                                "anthropic-version": "2023-06-01",
                                "Content-Type": "application/json"
                            },
                            json={
                                "model": "claude-opus-4-6-20260205",  # March 2026 assumed flagship
                                "max_tokens": 900,
                                "temperature": 0.3,
                                "system": system,
                                "messages": st.session_state.messages
                            },
                            timeout=60
                        )
                        resp.raise_for_status()
                        data = resp.json()
                        reply = data["content"][0]["text"]

                        st.session_state.messages.append({
                            "role": "assistant",
                            "content": reply,
                            "sources": sources_list
                        })
                        st.rerun()

                    except Exception as ex:
                        st.error(f"API error: {ex}")
                        if st.session_state.messages and st.session_state.messages[-1]["role"] == "user":
                            st.session_state.messages.pop()
                        st.rerun()

with tab_eval:
    st.header("Quick RAG Evaluation (March 2026)")

    test_set = [
        {"q": "What is your return policy?", "expected_faq_idx": 0},
        {"q": "How long for international shipping?", "expected_faq_idx": 1},
        {"q": "Can I cancel my order after one hour?", "expected_faq_idx": 4},
        {"q": "I forgot my password what do I do?", "expected_faq_idx": 3},
        {"q": "Do you have 24/7 support?", "expected_faq_idx": 2},
    ]

    if st.button("Run Retrieval Test", type="primary"):
        results = []
        for case in test_set:
            rel = retrieve_relevant(case["q"], top_k=3)
            retrieved_idxs = [st.session_state.faqs.index(r["faq"]) for r in rel]
            hit = case["expected_faq_idx"] in retrieved_idxs
            results.append({
                "query": case["q"],
                "hit@3": "Yes" if hit else "No",
                "top_scores": [f"{r['score']:.3f}" for r in rel[:3]]
            })

        st.dataframe(results)
        recall = sum(1 for r in results if r["hit@3"] == "Yes") / len(results)
        st.metric("Recall@3", f"{recall:.1%}")

st.markdown("---")
st.caption(f"FAQ RAG • Voyage-4-large + rerank-2.5 • Claude Opus 4.6 • {datetime.now().strftime('%Y-%m')}")