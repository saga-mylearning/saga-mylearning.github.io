# app.py - Local FAQ RAG Chat with Ollama (OpenAI-compatible client)
# March 2026 version – fully offline after model download

import streamlit as st
import json
import os
import numpy as np
from sentence_transformers import SentenceTransformer
from openai import OpenAI
from datetime import datetime

st.set_page_config(
    page_title="Local FAQ RAG • Ollama + OpenAI client",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ─── Styling ────────────────────────────────────────────────────────────────
st.markdown("""
    <style>
    :root {
        --bg: #0a0a0f;
        --surface: #12121a;
        --surface2: #1a1a26;
        --border: #2a2a3d;
        --accent: #7c6af5;
        --accent2: #c084fc;
        --text: #e8e8f0;
        --muted: #7070a0;
    }
    .stApp { background: var(--bg); color: var(--text); }
    section[data-testid="stSidebar"] {
        background: var(--surface) !important;
        border-right: 1px solid var(--border);
    }
    .stTextInput input, .stTextArea textarea {
        background: var(--surface2);
        border: 1px solid var(--border);
        color: var(--text);
        font-family: 'DM Mono', monospace;
    }
    .stButton > button {
        background: linear-gradient(135deg, var(--accent), var(--accent2));
        color: white;
        border: none;
    }
    .chat-user {
        background: #1e1b4b;
        border: 1px solid var(--accent);
        border-radius: 12px;
        border-bottom-right-radius: 2px;
        padding: 12px 16px;
        margin: 8px 0;
        max-width: 80%;
        align-self: flex-end;
        color: #c4b5fd;
    }
    .chat-bot {
        background: #131320;
        border: 1px solid var(--border);
        border-radius: 12px;
        border-bottom-left-radius: 2px;
        padding: 12px 16px;
        margin: 8px 0;
        max-width: 80%;
        align-self: flex-start;
        color: var(--text);
    }
    .sources {
        font-size: 0.75rem;
        color: var(--muted);
        margin-top: 6px;
    }
    .sources span {
        background: rgba(124,106,245,0.15);
        border: 1px solid rgba(124,106,245,0.3);
        color: var(--accent2);
        padding: 2px 8px;
        border-radius: 4px;
        margin-right: 4px;
    }
    .empty-hint {
        text-align: center;
        color: var(--muted);
        padding: 80px 20px;
        opacity: 0.6;
    }
    </style>
""", unsafe_allow_html=True)

# ─── Session & Persistence ──────────────────────────────────────────────────
FAQ_FILE = "faqs_local.json"

def load_faqs():
    if os.path.exists(FAQ_FILE):
        try:
            with open(FAQ_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except:
            pass
    return [
        {"q": "What is your return policy?", "a": "We offer a 30-day hassle-free return policy. Items must be unused and in original packaging."},
        {"q": "How long does shipping take?", "a": "Standard shipping takes 5–7 business days. Express shipping (2–3 days) is available."},
        {"q": "Do you offer customer support?", "a": "Yes! Support is available 24/7 via live chat, email and phone."},
        {"q": "How do I reset my password?", "a": "Click 'Forgot Password' on login page. Check spam if you don't see the email."},
        {"q": "Can I change or cancel my order?", "a": "Orders can be modified or cancelled within 1 hour of placement."},
    ]

if "faqs" not in st.session_state:
    st.session_state.faqs = load_faqs()

if "messages" not in st.session_state:
    st.session_state.messages = []

# ─── Local Embedder ─────────────────────────────────────────────────────────
@st.cache_resource
def load_embedder():
    return SentenceTransformer('all-MiniLM-L6-v2')

embedder = load_embedder()

def compute_faq_embeddings():
    if not st.session_state.faqs:
        st.session_state.faq_embeddings = None
        return
    texts = [f"{f['q']} {f['a']}" for f in st.session_state.faqs]
    st.session_state.faq_embeddings = embedder.encode(texts, normalize_embeddings=True)

if "faq_embeddings" not in st.session_state:
    compute_faq_embeddings()

# ─── Retrieval ──────────────────────────────────────────────────────────────
def retrieve_relevant(query: str, top_k: int = 4, min_score: float = 0.32):
    if "faq_embeddings" not in st.session_state or st.session_state.faq_embeddings is None:
        return []
    q_emb = embedder.encode([query], normalize_embeddings=True)[0]
    sims = np.dot(st.session_state.faq_embeddings, q_emb)
    idx = np.argsort(sims)[::-1][:top_k]
    return [
        {"faq": st.session_state.faqs[i], "score": float(sims[i])}
        for i in idx if sims[i] >= min_score
    ]

# ─── Ollama OpenAI-compatible client ────────────────────────────────────────
@st.cache_resource
def get_ollama_client():
    return OpenAI(
        base_url="http://localhost:11434/v1",
        api_key="ollama"  # dummy value – Ollama doesn't need real key
    )

# ─── Sidebar ────────────────────────────────────────────────────────────────
with st.sidebar:
    st.title("Local FAQ RAG Chat")
    st.caption("Ollama + sentence-transformers • OpenAI client style")

    ollama_model = st.selectbox(
        "Ollama Model",
        options=[
            "llama3.1:8b",
            "llama3.2:3b",
            "qwen2.5:7b",
            "qwen2.5:14b",
            "gemma2:9b",
            "gemma2:27b",
            "phi-4:14b",
            "mistral-nemo:12b",
        ],
        index=0,
        help="Choose model you already pulled with ollama pull ..."
    )

    st.divider()
    st.subheader("Knowledge Base")
    st.caption(f"{len(st.session_state.faqs)} entries loaded")

    new_q = st.text_input("New Question", key="new_q")
    new_a = st.text_area("Answer", height=100, key="new_a")

    if st.button("➕ Add FAQ", use_container_width=True):
        q = new_q.strip()
        a = new_a.strip()
        if q and a:
            st.session_state.faqs.append({"q": q, "a": a})
            with open(FAQ_FILE, "w", encoding="utf-8") as f:
                json.dump(st.session_state.faqs, f, ensure_ascii=False, indent=2)
            compute_faq_embeddings()
            st.success("FAQ added", icon="✅")
            st.rerun()
        else:
            st.warning("Both question and answer required")

    st.divider()

    for i, faq in enumerate(st.session_state.faqs):
        with st.expander(f"{faq['q'][:52]}{'…' if len(faq['q']) > 52 else ''}"):
            st.markdown(f"**Q:** {faq['q']}")
            st.markdown(f"**A:** {faq['a']}")
            if st.button("🗑 Delete", key=f"del_{i}", use_container_width=True):
                st.session_state.faqs.pop(i)
                with open(FAQ_FILE, "w", encoding="utf-8") as f:
                    json.dump(st.session_state.faqs, f, ensure_ascii=False, indent=2)
                compute_faq_embeddings()
                st.rerun()

# ─── Main Chat Area ─────────────────────────────────────────────────────────
st.header("Local RAG Chat with Ollama")

chat_container = st.container()

with chat_container:
    if not st.session_state.messages:
        st.markdown(
            '<div class="empty-hint">Add some FAQs in the sidebar<br>and start asking questions</div>',
            unsafe_allow_html=True
        )

    for msg in st.session_state.messages:
        if msg["role"] == "user":
            st.markdown(f'<div class="chat-user">{msg["content"]}</div>', unsafe_allow_html=True)
        else:
            sources_html = ""
            if msg.get("sources"):
                sources_html = '<div class="sources">📎 ' + \
                               " ".join(f'<span>{s}</span>' for s in msg["sources"]) + \
                               '</div>'
            st.markdown(
                f'<div class="chat-bot">{msg["content"]}{sources_html}</div>',
                unsafe_allow_html=True
            )

# ─── Input ──────────────────────────────────────────────────────────────────
if prompt := st.chat_input("Ask anything about orders, returns, support..."):
    st.session_state.messages.append({"role": "user", "content": prompt})

    # RAG step
    relevant = retrieve_relevant(prompt)

    sources_list = []
    context = ""
    if relevant:
        context = "### Most relevant FAQ entries (use ONLY these to answer):\n\n"
        for i, item in enumerate(relevant, 1):
            f = item["faq"]
            context += f"FAQ {i} (score {item['score']:.2f}):\nQ: {f['q']}\nA: {f['a']}\n\n"
            short_q = f['q'][:38] + "…" if len(f['q']) > 38 else f['q']
            sources_list.append(f"{short_q} ({item['score']:.2f})")
    else:
        context = "### No relevant FAQ entries found.\n"

    system_content = f"""You are a helpful and concise customer support assistant.
Answer using ONLY the provided FAQ entries when possible.
If the question is not covered by the FAQs, politely say so.

{context}"""

    # Build messages with system prompt
    messages = [{"role": "system", "content": system_content}] + st.session_state.messages

    # Generate response (streaming)
    with st.chat_message("assistant"):
        message_placeholder = st.empty()
        full_response = ""

        client = get_ollama_client()

        stream = client.chat.completions.create(
            model=ollama_model,
            messages=messages,
            temperature=0.35,
            stream=True,
            max_tokens=1200,
        )

        for chunk in stream:
            if chunk.choices[0].delta.content is not None:
                full_response += chunk.choices[0].delta.content
                message_placeholder.markdown(full_response + "▌")

        message_placeholder.markdown(full_response)

        # Save to history
        st.session_state.messages.append({
            "role": "assistant",
            "content": full_response,
            "sources": sources_list if sources_list else None
        })