# app.py
import streamlit as st
import requests
import json
import re
from datetime import datetime

st.set_page_config(
    page_title="FAQ RAG Chat",
    page_icon="🔮",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ─── Styling ────────────────────────────────────────────────────────────────
st.markdown("""
    <style>
    :root {
        --bg: #0a0a0f;
        --surface: #12121a;
        --surface2: #1a1a26;
        --border: #2a2a3d;
        --accent: #7c6af5;
        --accent2: #c084fc;
        --text: #e8e8f0;
        --muted: #7070a0;
    }

    .stApp {
        background: var(--bg);
        color: var(--text);
    }

    section[data-testid="stSidebar"] {
        background: var(--surface) !important;
        border-right: 1px solid var(--border);
    }

    .stTextInput > div > div > input,
    .stTextArea > div > div > textarea {
        background: var(--surface2);
        border: 1px solid var(--border);
        color: var(--text);
        font-family: 'DM Mono', monospace;
    }

    .stButton > button {
        background: linear-gradient(135deg, var(--accent), var(--accent2));
        color: white;
        border: none;
        font-weight: bold;
        letter-spacing: 0.5px;
    }

    .stButton > button:hover {
        opacity: 0.92;
        transform: translateY(-1px);
    }

    .chat-user {
        background: #1e1b4b;
        border: 1px solid var(--accent);
        border-radius: 12px;
        border-bottom-right-radius: 2px;
        padding: 12px 16px;
        margin: 8px 0;
        max-width: 80%;
        align-self: flex-end;
        color: #c4b5fd;
        font-size: 0.95rem;
        line-height: 1.55;
    }

    .chat-bot {
        background: #131320;
        border: 1px solid var(--border);
        border-radius: 12px;
        border-bottom-left-radius: 2px;
        padding: 12px 16px;
        margin: 8px 0;
        max-width: 80%;
        align-self: flex-start;
        color: var(--text);
        font-size: 0.95rem;
        line-height: 1.55;
    }

    .sources {
        font-size: 0.75rem;
        color: var(--muted);
        margin-top: 6px;
    }

    .sources span {
        background: rgba(124,106,245,0.15);
        border: 1px solid rgba(124,106,245,0.3);
        color: var(--accent2);
        padding: 2px 8px;
        border-radius: 4px;
        margin-right: 4px;
    }

    .empty-hint {
        text-align: center;
        color: var(--muted);
        padding: 80px 20px;
        opacity: 0.6;
    }

    hr {
        border-color: var(--border) !important;
    }
    </style>
""", unsafe_allow_html=True)


# ─── Session State ──────────────────────────────────────────────────────────
if "faqs" not in st.session_state:
    st.session_state.faqs = [
        {"q": "What is your return policy?", 
         "a": "We offer a 30-day hassle-free return policy. Items must be unused and in original packaging. Contact support@example.com to initiate a return."},
        {"q": "How long does shipping take?", 
         "a": "Standard shipping takes 5–7 business days. Express shipping (2–3 days) is available at checkout. International orders may take 10–14 days."},
        {"q": "Do you offer customer support?", 
         "a": "Yes! Our support team is available 24/7 via live chat, email at support@example.com, and phone at 1-800-555-0100."},
        {"q": "How do I reset my password?", 
         "a": "Go to the login page and click 'Forgot Password'. Enter your email and we'll send a reset link within 2 minutes. Check your spam folder if you don't see it."},
        {"q": "Can I change or cancel my order?", 
         "a": "Orders can be modified or cancelled within 1 hour of placement. After that, the order enters processing and changes may not be possible."},
    ]

if "messages" not in st.session_state:
    st.session_state.messages = []

if "api_key" not in st.session_state:
    st.session_state.api_key = ""


# ─── Simple keyword-based retrieval (same logic as original) ────────────────
def retrieve_relevant(query: str, top_k: int = 3):
    words = set(re.findall(r'\w+', query.lower()))
    if not words:
        return []
    
    scored = []
    for i, faq in enumerate(st.session_state.faqs):
        text = (faq["q"] + " " + faq["a"]).lower()
        score = sum(1 for w in words if w in text)
        if score > 0:
            scored.append((score, i, faq))
    
    scored.sort(reverse=True)  # highest score first
    top = scored[:top_k]
    return [item[2] for item in top]


# ─── Sidebar ────────────────────────────────────────────────────────────────
with st.sidebar:

    st.markdown("<h3 style='font-family: Syne, sans-serif; letter-spacing: 1.5px;'>Knowledge Base</h3>", unsafe_allow_html=True)
    st.caption(f"{len(st.session_state.faqs)} entries loaded")

    st.divider()

    new_q = st.text_input("Question", key="new_q_input", placeholder="e.g. What is your warranty policy?")
    new_a = st.text_area("Answer", key="new_a_input", placeholder="Detailed answer...", height=110)

    if st.button("➕ Add FAQ Entry", use_container_width=True):
        q = new_q.strip()
        a = new_a.strip()
        if q and a:
            st.session_state.faqs.append({"q": q, "a": a})
            st.success("FAQ added!", icon="✅")
            st.rerun()
        else:
            st.warning("Both question and answer are required.", icon="⚠️")

    st.divider()

    st.markdown("**Current FAQs**")
    for i, faq in enumerate(st.session_state.faqs):
        with st.expander(f"{faq['q'][:60]}{'…' if len(faq['q']) > 60 else ''}"):
            st.markdown(f"**Q:** {faq['q']}")
            st.markdown(f"**A:** {faq['a']}")
            if st.button("🗑 Delete", key=f"del_{i}", use_container_width=True):
                st.session_state.faqs.pop(i)
                st.rerun()


# ─── Main Chat Area ─────────────────────────────────────────────────────────
st.markdown("<h2 style='font-family: Syne, sans-serif; background: linear-gradient(90deg, #7c6af5, #c084fc); -webkit-background-clip: text; -webkit-text-fill-color: transparent; letter-spacing: -0.5px;'>FAQ·RAG Chat</h2>", unsafe_allow_html=True)

api_key = st.text_input(
    "Anthropic API Key (Claude)",
    value=st.session_state.api_key,
    type="password",
    placeholder="sk-ant-...",
    key="api_key_input"
)
if api_key != st.session_state.api_key:
    st.session_state.api_key = api_key

st.divider()

# Chat messages
chat_container = st.container()

with chat_container:
    if not st.session_state.messages:
        st.markdown(
            '<div class="empty-hint">Add FAQ entries in the sidebar<br>and start asking questions ✨</div>',
            unsafe_allow_html=True
        )

    for msg in st.session_state.messages:
        if msg["role"] == "user":
            st.markdown(f'<div class="chat-user">{msg["content"]}</div>', unsafe_allow_html=True)
        else:
            content = msg["content"]
            sources = msg.get("sources", [])
            source_html = ""
            if sources:
                source_html = '<div class="sources">📎 Sources: ' + \
                              " ".join(f'<span>{s}</span>' for s in sources) + \
                              '</div>'
            
            st.markdown(
                f'<div class="chat-bot">{content}{source_html}</div>',
                unsafe_allow_html=True
            )


# Input area
user_input = st.chat_input("Ask anything...")

if user_input:
    if not st.session_state.api_key.strip():
        st.error("Please enter your Anthropic API key first.", icon="🔑")
    else:
        # Add user message
        st.session_state.messages.append({"role": "user", "content": user_input})

        # RAG
        relevant_faqs = retrieve_relevant(user_input)
        sources = []

        if relevant_faqs:
            context = "### Retrieved FAQ Entries (use these to answer):\n\n"
            for i, faq in enumerate(relevant_faqs, 1):
                context += f"**FAQ {i}:**\nQ: {faq['q']}\nA: {faq['a']}\n\n"
                short_q = faq['q'][:38] + "…" if len(faq['q']) > 38 else faq['q']
                sources.append(f"FAQ: {short_q}")
        else:
            context = "### No relevant FAQ entries found. Answer based on general knowledge or say you don't have specific information.\n\n"

        system_prompt = f"""You are a helpful customer support assistant powered by a FAQ knowledge base.
Answer the user's question using ONLY the retrieved FAQ entries provided. 
Be concise, friendly, and accurate. If the FAQ entries don't cover the question, say so politely.

{context}"""

        # Show assistant placeholder
        with st.chat_message("assistant"):
            with st.spinner("Thinking..."):
                try:
                    resp = requests.post(
                        "https://api.anthropic.com/v1/messages",
                        headers={
                            "x-api-key": st.session_state.api_key,
                            "anthropic-version": "2023-06-01",
                            "Content-Type": "application/json"
                        },
                        json={
                            "model": "claude-3-5-sonnet-20241022",  # ← update to current model name
                            "max_tokens": 1000,
                            "system": system_prompt,
                            "messages": st.session_state.messages
                        },
                        timeout=45
                    )

                    if resp.status_code != 200:
                        error = resp.json().get("error", {}).get("message", "Unknown error")
                        st.error(f"API Error: {error}")
                        # remove last user message on failure
                        st.session_state.messages.pop()
                    else:
                        data = resp.json()
                        reply = data["content"][0]["text"]
                        st.session_state.messages.append({
                            "role": "assistant",
                            "content": reply,
                            "sources": sources
                        })
                        st.rerun()

                except Exception as ex:
                    st.error(f"Request failed: {ex}")
                    st.session_state.messages.pop()